txt = "Hello World"
x = txt[0]
