age = 36
txt = "My name is John, and I am {}"
print(txt.format(age))
