txt = "Hello World"
txt = txt.lower()
