txt = " Hello World "
x = txt.strip()
