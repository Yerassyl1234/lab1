x = "Hello World"
print(len(x))
