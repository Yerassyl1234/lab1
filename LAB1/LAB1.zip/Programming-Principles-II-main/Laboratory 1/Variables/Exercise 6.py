x = y = z = "Orange"
