def myfunc():
    global x
    x = "fantastic"
