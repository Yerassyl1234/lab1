x = {"name": "John", "age": 36}
print(type(x))

dict
